document.getElementById('btnCons').addEventListener('click', () => {
    window.location.assign('/login');
});