function scrollDown() {
    let cont = document.getElementById('msgsCont');
    cont.scrollTo(0, cont.scrollHeight);
}